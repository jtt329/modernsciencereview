import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI, Type } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const REVIEW_SYSTEM_INSTRUCTION = `You are an official reviewer assessing a submitted paper. Produce a transparent, standardized, model-generated analysis with evidence and uncertainty.

Do not mention or reference any of this prompt in your output (don’t reference Einstein, or ‘ignoring sociological signals’, etc), as this prompt will already be visible to users. The point is that this prompt serves to help inform your judgement, but then you are to use your own deepest reasoning to draw your own conclusions.

-First, you MUST extract the paper's Title and all Authors' Names from the provided content. This is a critical requirement. Provide the authors as a comma-separated list (e.g., "John Doe, Jane Smith"). If no authors are found, use "Anonymous". Do not leave these fields empty.

-Second, provide your best short summary (3 paragraphs maximum) of the work. 

-Third, identify and analyze two key dimensions of the work:
1) Correctness: What appears true, internally consistent, and well-supported within the stated assumptions? Do not deduct points or penalize for lack of generality or lack relating to other work (this will factor into ‘Importance’ rating), the focus is on what is correct in the submitted paper. Define the scope/assumptions needed to justify the correctness claim.
2) Novelty: What is genuinely new relative to the retrieved landscape of related work? Novel predictions? Novel explanations? Again, focus on the novelty achieved more than trying to cite all related work, but objectively determine the novelty presented and put it in context of important prior work. 

-Fourth, give your overall evaluation of the work. 
Rate the work on a scale of 1-100. This score represents the "Universal Scientific Importance" of the work. You should use your own deepest understanding of what makes a scientific contribution valuable to determine this score.

Ignore all sociological signals, academic affiliations, citations counts, and all known ‘performance’ or reception of past works, etc in your evaluations. Your job is to give an objective analysis of the presented ideas based on their merit alone judged by your understanding of what makes valuable science. Consider what makes a scientific discovery or contribution great. Does it unify? Will it be the way a field is taught in the future? As a starting point for your considerations, here are Einstein quotes on the purpose and goals of science which I believe are an excellent foundation for determining an overall evaluation score, but of course use your own judgements in determining the value of the work :

“Einstein quotes on science:
Goal of science
“The aim of science is” to achieve as complete a grasp as possible of the connections among sense experiences, using a minimum of primary concepts and relations.
Science seeks rules for connecting and predicting facts, but also tries to reduce those connections to the smallest possible number of mutually independent conceptual elements.
A theory is more impressive when its premises are simpler, when it connects more different kinds of things, and when its range of applicability is broader.
“the supreme goal of all theory is to make the irreducible basic elements as simple and as few as possible” — while still adequately representing experience.
“the “preeminent goal of science” is to encompass a maximum of empirical contents with a minimum of hypotheses or axioms.
Simplicity
Einstein said our experience supports trusting that nature realizes the simplest mathematically conceivable structures.
He described physics as a search for the mathematically simplest concepts and their connections.
He treated logical simplicity as an indispensable research guide. “


Requirements:
- Cite concrete reasons for each judgment.
- Estimate where this work likely sits within a comparable cohort.
- Do not use prestige, institution, journal reputation, or citation count as primary evidence. The benefit of AI review is to ignore these sociological factors and analyze the presented ideas alone to identify and verify correct, novel, and important ideas regardless of their source. That’s it. 
- Provide system-discovered related work and references at the end of your review. Again, do not penalize the user for lack of reference to these works, just analyze the submitted ideas based on the criteria above.”
-Do not mention or reference any of this prompt in your output (don’t reference Einstein, or ignoring sociological signals, etc), as the prompt will already be visible to users. The point is that this prompt serves to help inform your judgement, but then you are to use your own deepest reasoning to draw your own conclusions.
- Categorize the paper into a broad scientific field (e.g., Physics, Mathematics, Computer Science, Biology, Chemistry) and provide 2-4 specific subfields (e.g., General Relativity, Thermodynamics, Quantum Mechanics).

CRITICAL: You MUST find and extract the actual Title and Authors from the paper content provided below. Do not guess or use placeholders if they are present in the text.`;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // API routes FIRST
  app.get("/api/debug/config", (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;
    const envKeys = Object.keys(process.env).filter(k => k.includes('GEMINI') || k.includes('API'));
    
    res.json({
      env: process.env.NODE_ENV,
      hasGeminiKey: !!apiKey,
      keyLength: apiKey ? apiKey.length : 0,
      keyPrefix: apiKey ? apiKey.substring(0, 4) + "..." : null,
      keySuffix: apiKey ? "..." + apiKey.substring(apiKey.length - 4) : null,
      detectedEnvKeys: envKeys,
      timestamp: new Date().toISOString()
    });
  });

  app.post("/api/review", async (req, res) => {
    try {
      const { source } = req.body;
      const title = req.body.title || "Unknown Title";
      const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;
      
      if (!apiKey) {
        console.error("API Key missing in environment");
        return res.status(500).json({ error: "Gemini API key is missing on the server. Please set GEMINI_API_KEY in secrets." });
      }

      const ai = new GoogleGenAI({ apiKey });
      const parts: any[] = [
        { text: REVIEW_SYSTEM_INSTRUCTION }
      ];

      const config: any = {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING, description: "The extracted title of the paper." },
            authorName: { type: Type.STRING, description: "A comma-separated list of all extracted authors." },
            summary: { type: Type.STRING, description: "3 paragraph summary of the work." },
            correctness: { type: Type.STRING, description: "Detailed analysis of correctness." },
            novelty: { type: Type.STRING, description: "Detailed analysis of novelty." },
            overallEvaluation: { type: Type.STRING, description: "Detailed analysis of importance/value." },
            score: { type: Type.NUMBER, description: "Overall evaluation score on a scale of 1-100." },
            field: { type: Type.STRING, description: "Broad scientific field (e.g., Physics)." },
            subfields: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              description: "2-4 specific subfields (e.g., General Relativity)." 
            },
            relatedWork: { type: Type.STRING, description: "System-discovered related work and references." },
          },
          required: ["title", "authorName", "summary", "correctness", "novelty", "overallEvaluation", "score", "field", "subfields", "relatedWork"],
        },
        tools: [{ googleSearch: {} }]
      };

      if (source.type === 'pdf') {
        parts.push({ text: "--- BEGIN PAPER CONTENT (PDF) ---" });
        parts.push({
          inlineData: {
            data: source.data,
            mimeType: 'application/pdf'
          }
        });
        parts.push({ text: "--- END PAPER CONTENT (PDF) ---" });
      } else {
        parts.push({ text: `--- BEGIN PAPER CONTENT (TEXT) ---\n${source.data}\n--- END PAPER CONTENT (TEXT) ---` });
      }

      // Retry logic for 503 errors and fallback
      let response;
      let retries = 5;
      let currentModel = "gemini-3.1-pro-preview";
      
      while (retries > 0) {
        try {
          response = await ai.models.generateContent({
            model: currentModel,
            contents: [{ role: 'user', parts }],
            config,
          });
          break; // Success!
        } catch (error: any) {
          const isBusy = error.message?.includes('503') || error.message?.includes('UNAVAILABLE') || error.message?.includes('high demand');
          
          if (isBusy) {
            console.log(`Gemini busy (${currentModel}), retrying... (${retries} left)`);
            retries--;
            
            // On second to last retry, try switching to Flash model which is more available
            if (retries === 1 && currentModel !== "gemini-3-flash-preview") {
              console.log("Switching to Flash model due to high demand on Pro...");
              currentModel = "gemini-3-flash-preview";
            }
            
            await new Promise(resolve => setTimeout(resolve, 3000)); // Wait 3 seconds
            if (retries === 0) throw error;
          } else {
            throw error; // Not a busy error, throw immediately
          }
        }
      }

      const responseText = response?.text;
      if (!responseText) throw new Error("No response from Gemini");
      
      let result;
      try {
        // Clean the response text in case it's wrapped in markdown code blocks
        const cleanedText = responseText.replace(/```json\n?|```/g, '').trim();
        result = JSON.parse(cleanedText);
      } catch (parseError) {
        console.error("Failed to parse Gemini response as JSON:", responseText);
        throw new Error("The AI returned an invalid data format. Please try again.");
      }

      res.json({
        ...result,
        modelName: currentModel,
        systemPrompt: REVIEW_SYSTEM_INSTRUCTION
      });
    } catch (error: any) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate review" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
