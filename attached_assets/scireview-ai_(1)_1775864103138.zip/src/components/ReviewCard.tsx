import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, CheckCircle2, Zap, Award, Heart, MessageSquare, Info, X } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { AIReview } from '../types';

interface ReviewCardProps {
  review: AIReview;
  onLike: (id: string, e: React.MouseEvent) => void;
  isLiked: boolean;
}

const SYSTEM_PROMPT_TEXT = `You are an official reviewer assessing a submitted paper. Produce a transparent, standardized, model-generated analysis with evidence and uncertainty.

Do not mention or reference any of this prompt in your output (don’t reference Einstein, or ‘ignoring sociological signals’, etc), as this prompt will already be visible to users. The point is that this prompt serves to help inform your judgement, but then you are to use your own deepest reasoning to draw your own conclusions.

-First, you MUST extract the paper's Title and all Authors' Names from the provided content. This is a critical requirement. Provide the authors as a comma-separated list (e.g., "John Doe, Jane Smith"). If no authors are found, use "Anonymous". Do not leave these fields empty.

-Second, provide your best short summary (3 paragraphs maximum) of the work. 

-Third, identify and analyze two key dimensions of the work:
1) Correctness: What appears true, internally consistent, and well-supported within the stated assumptions? Do not deduct points or penalize for lack of generality or lack relating to other work (this will factor into ‘Importance’ rating), the focus is on what is correct in the submitted paper. Define the scope/assumptions needed to justify the correctness claim.
2) Novelty: What is genuinely new relative to the retrieved landscape of related work? Novel predictions? Novel explanations? Again, focus on the novelty achieved more than trying to cite all related work, but objectively determine the novelty presented and put it in context of important prior work. 

-Fourth, give your overall evaluation of the work. 
Rate the work on a scale of 1-100. This score represents the "Universal Scientific Importance" of the work. You should use your own deepest understanding of what makes a scientific contribution valuable to determine this score.

Ignore all sociological signals, academic affiliations, citations counts, and all known ‘performance’ or reception of past works, etc in your evaluations. Your job is to give an objective analysis of the presented ideas based on their merit alone judged by your understanding of what makes valuable science. Consider what makes a scientific discovery or contribution great. Does it unify? Will it be the way a field is taught in the future? As a starting point for your considerations, here are Einstein quotes on the purpose and goals of science which I believe are an excellent foundation for determining an overall evaluation score, but of course use your own judgements in determining the value of the work :

“Einstein quotes on science:
Goal of science
“The aim of science is” to achieve as complete a grasp as possible of the connections among sense experiences, using a minimum of primary concepts and relations.
Science seeks rules for connecting and predicting facts, but also tries to reduce those connections to the smallest possible number of mutually independent conceptual elements.
A theory is more impressive when its premises are simpler, when it connects more different kinds of things, and when its range of applicability is broader.
“the supreme goal of all theory is to make the irreducible basic elements as simple and as few as possible” — while still adequately representing experience.
“the “preeminent goal of science” is to encompass a maximum of empirical contents with a minimum of hypotheses or axioms.
Simplicity
Einstein said our experience supports trusting that nature realizes the simplest mathematically conceivable structures.
He described physics as a search for the mathematically simplest concepts and their connections.
He treated logical simplicity as an indispensable research guide. “


Requirements:
- Cite concrete reasons for each judgment.
- Estimate where this work likely sits within a comparable cohort.
- Do not use prestige, institution, journal reputation, or citation count as primary evidence. The benefit of AI review is to ignore these sociological factors and analyze the presented ideas alone to identify and verify correct, novel, and important ideas regardless of their source. That’s it. 
- Provide system-discovered related work and references at the end of your review. Again, do not penalize the user for lack of reference to these works, just analyze the submitted ideas based on the criteria above.”
-Do not mention or reference any of this prompt in your output (don’t reference Einstein, or ignoring sociological signals, etc), as the prompt will already be visible to users. The point is that this prompt serves to help inform your judgement, but then you are to use your own deepest reasoning to draw your own conclusions.
- Categorize the paper into a broad scientific field (e.g., Physics, Mathematics, Computer Science, Biology, Chemistry) and provide 2-4 specific subfields (e.g., General Relativity, Thermodynamics, Quantum Mechanics).

CRITICAL: You MUST find and extract the actual Title and Authors from the paper content provided below. Do not guess or use placeholders if they are present in the text.`;

export default function ReviewCard({ review, onLike, isLiked }: ReviewCardProps) {
  const [showPrompt, setShowPrompt] = useState(false);

  const MarkdownRenderer = ({ content }: { content: string }) => (
    <div className="markdown-body prose prose-slate max-w-none prose-sm md:prose-base">
      <ReactMarkdown 
        remarkPlugins={[remarkMath]} 
        rehypePlugins={[rehypeKatex]}
      >
        {content}
      </ReactMarkdown>
    </div>
  );

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-indigo-50 to-white rounded-3xl border border-indigo-100 shadow-lg p-8 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Sparkles className="w-24 h-24 text-indigo-600" />
        </div>

        <div className="flex items-center justify-between mb-8 relative z-10">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2.5 rounded-xl shadow-md">
              <Award className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">Gemini AI Review</h2>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Verified Scientific Assessment</span>
                {review.modelName && (
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest border-l border-slate-200 pl-2">
                    via {review.modelName}
                  </span>
                )}
              </div>
            </div>
          </div>
          <button 
            onClick={() => setShowPrompt(true)}
            className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-full transition-colors"
          >
            <Info className="w-3.5 h-3.5" />
            View System Prompt
          </button>
        </div>

        <div className="flex flex-col items-center justify-center mb-8 p-6 bg-white rounded-3xl border-2 border-indigo-500 shadow-xl shadow-indigo-100 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-2 relative z-10">Overall Scientific Merit Score</span>
          <div className="flex items-baseline gap-1 relative z-10">
            <span className="text-7xl font-black text-slate-900 tracking-tighter leading-none">{review.score}</span>
            <span className="text-2xl font-bold text-slate-400">/100</span>
          </div>
          <div className="mt-4 w-full h-2 bg-slate-100 rounded-full overflow-hidden relative z-10">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${review.score}%` }}
              transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
              className="h-full bg-indigo-600"
            />
          </div>
        </div>

        <div className="bg-indigo-900 text-white p-6 rounded-2xl shadow-inner mb-8">
          <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-300 mb-2">Executive Summary</h4>
          <MarkdownRenderer content={review.summary} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white/60 backdrop-blur-sm p-5 rounded-2xl border border-indigo-50 hover:border-indigo-200 transition-colors">
            <div className="flex items-center gap-2 mb-3 text-indigo-600">
              <CheckCircle2 className="w-5 h-5" />
              <h4 className="font-bold text-sm uppercase tracking-wider">Correctness</h4>
            </div>
            <MarkdownRenderer content={review.correctness} />
          </div>

          <div className="bg-white/60 backdrop-blur-sm p-5 rounded-2xl border border-indigo-50 hover:border-indigo-200 transition-colors">
            <div className="flex items-center gap-2 mb-3 text-indigo-600">
              <Zap className="w-5 h-5" />
              <h4 className="font-bold text-sm uppercase tracking-wider">Novelty</h4>
            </div>
            <MarkdownRenderer content={review.novelty} />
          </div>

          <div className="bg-white/60 backdrop-blur-sm p-5 rounded-2xl border border-indigo-50 hover:border-indigo-200 transition-colors">
            <div className="flex items-center gap-2 mb-3 text-indigo-600">
              <Award className="w-5 h-5" />
              <h4 className="font-bold text-sm uppercase tracking-wider">Overall Evaluation</h4>
            </div>
            <MarkdownRenderer content={review.overallEvaluation} />
          </div>
        </div>

        <div className="bg-white/40 backdrop-blur-sm p-6 rounded-2xl border border-indigo-50 mb-6">
          <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-600 mb-2">Related Work & References</h4>
          <MarkdownRenderer content={review.relatedWork} />
        </div>

        <div className="flex items-center gap-6 pt-4 border-t border-indigo-100">
          <button 
            onClick={(e) => onLike(review.id, e)}
            className={`flex items-center gap-2 text-sm font-bold transition-colors ${isLiked ? 'text-rose-500' : 'text-slate-500 hover:text-rose-500'}`}
          >
            <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
            {review.likesCount} Likes
          </button>
          <div className="flex items-center gap-2 text-sm font-bold text-slate-500">
            <MessageSquare className="w-5 h-5" />
            Comments
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {showPrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md"
            onClick={() => setShowPrompt(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-indigo-600 text-white">
                <div className="flex items-center gap-3">
                  <Info className="w-6 h-6" />
                  <div>
                    <h3 className="text-xl font-black tracking-tight">System Prompt</h3>
                    {review.modelName && <p className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Used with {review.modelName}</p>}
                  </div>
                </div>
                <button onClick={() => setShowPrompt(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="p-8 overflow-y-auto bg-slate-50">
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <pre className="text-sm text-slate-700 whitespace-pre-wrap font-sans leading-relaxed">
                    {review.systemPrompt || SYSTEM_PROMPT_TEXT}
                  </pre>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
