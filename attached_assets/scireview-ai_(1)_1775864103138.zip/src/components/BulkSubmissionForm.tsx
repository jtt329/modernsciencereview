import React, { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, X, BookOpen, Sparkles, Loader2, FileText, Upload, CheckCircle2, AlertCircle, Layers } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { ReviewSource } from '../services/geminiService';

interface BulkSubmissionFormProps {
  onSubmit: (source: ReviewSource, skipSelect?: boolean) => Promise<void>;
  onClose: () => void;
}

interface FileProgress {
  file: File;
  status: 'pending' | 'processing' | 'completed' | 'error';
  error?: string;
}

export default function BulkSubmissionForm({ onSubmit, onClose }: BulkSubmissionFormProps) {
  const [files, setFiles] = useState<FileProgress[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles
      .filter(f => f.type === 'application/pdf')
      .map(f => ({ file: f, status: 'pending' as const }));
    setFiles(prev => [...prev, ...newFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    multiple: true,
    disabled: isSubmitting
  });

  const handleBulkSubmit = async (retryOnly = false) => {
    if (files.length === 0) return;
    
    setIsSubmitting(true);
    setGlobalError(null);

    for (let i = 0; i < files.length; i++) {
      const currentFile = files[i];
      if (currentFile.status === 'completed') continue;
      if (retryOnly && currentFile.status !== 'error') continue;

      // Update status to processing
      setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'processing', error: undefined } : f));

      try {
        const file = currentFile.file;
        const base64 = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve((reader.result as string).split(',')[1]);
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });

        await onSubmit({ type: 'pdf', data: base64 }, true);
        
        // Update status to completed
        setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'completed' } : f));

        // Wait a bit before the next one to avoid rate limits
        if (i < files.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      } catch (err: any) {
        console.error(`Failed to process ${files[i].file.name}:`, err);
        setFiles(prev => prev.map((f, idx) => idx === i ? { ...f, status: 'error', error: err.message || 'Failed to process' } : f));
      }
    }

    setIsSubmitting(false);
  };

  const removeFile = (index: number) => {
    if (isSubmitting) return;
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const pendingCount = files.filter(f => f.status === 'pending').length;
  const completedCount = files.filter(f => f.status === 'completed').length;
  const processingCount = files.filter(f => f.status === 'processing').length;
  const errorCount = files.filter(f => f.status === 'error').length;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-xl">
              <Layers className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight">Bulk PDF Upload</h2>
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Admin Only Tool</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          <div 
            {...getRootProps()} 
            className={`border-2 border-dashed rounded-3xl p-12 text-center transition-all cursor-pointer ${
              isDragActive ? 'border-indigo-500 bg-indigo-50' : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
            }`}
          >
            <input {...getInputProps()} />
            <div className="flex flex-col items-center gap-4">
              <div className="bg-indigo-50 p-4 rounded-full">
                <Upload className="w-12 h-12 text-indigo-600" />
              </div>
              <div>
                <p className="text-lg font-bold text-slate-900">Drop multiple PDFs here</p>
                <p className="text-sm text-slate-500">They will be processed and reviewed one by one</p>
              </div>
            </div>
          </div>

          {files.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest">Queue ({files.length} files)</h3>
                <div className="flex gap-4 text-[10px] font-bold uppercase tracking-wider">
                  <span className="text-slate-400">{pendingCount} Pending</span>
                  <span className="text-indigo-600">{processingCount} Processing</span>
                  <span className="text-emerald-600">{completedCount} Completed</span>
                  <span className="text-rose-600">{errorCount} Failed</span>
                </div>
              </div>
              
              <div className="space-y-2">
                {files.map((f, i) => (
                  <div key={i} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="flex items-center gap-3 overflow-hidden">
                      <FileText className={`w-5 h-5 flex-shrink-0 ${f.status === 'completed' ? 'text-emerald-500' : 'text-slate-400'}`} />
                      <div className="flex flex-col overflow-hidden">
                        <span className="text-sm font-bold text-slate-900 truncate">{f.file.name}</span>
                        <span className="text-[10px] text-slate-500 font-medium">{(f.file.size / 1024 / 1024).toFixed(2)} MB</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      {f.status === 'processing' && <Loader2 className="w-4 h-4 text-indigo-600 animate-spin" />}
                      {f.status === 'completed' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                      {f.status === 'error' && (
                        <div className="flex flex-col items-end gap-1">
                          <div className="flex items-center gap-2 text-rose-500">
                            <AlertCircle className="w-4 h-4" />
                            <span className="text-[10px] font-bold uppercase">Error</span>
                          </div>
                          {f.error && (
                            <span className="text-[10px] text-rose-400 max-w-[250px] truncate" title={f.error}>
                              {f.error}
                            </span>
                          )}
                        </div>
                      )}
                      {f.status === 'pending' && !isSubmitting && (
                        <button onClick={() => removeFile(i)} className="p-1 hover:bg-slate-200 rounded-lg transition-colors">
                          <X className="w-4 h-4 text-slate-400" />
                        </button>
                      )}
                      {f.status === 'error' && !isSubmitting && (
                        <button onClick={() => removeFile(i)} className="p-1 hover:bg-slate-200 rounded-lg transition-colors">
                          <X className="w-4 h-4 text-slate-400" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-500">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <span className="text-sm font-bold uppercase tracking-wider">
              {isSubmitting ? `Processing ${completedCount + 1}/${files.length}...` : 'Ready to start bulk review'}
            </span>
          </div>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              disabled={isSubmitting}
              className="px-6 py-4 rounded-2xl font-bold text-slate-600 hover:bg-slate-100 transition-all"
            >
              Cancel
            </button>
            
            {/* If we have errors and no pending, the main button should be Retry Failed */}
            {errorCount > 0 && pendingCount === 0 && !isSubmitting ? (
              <>
                <button
                  onClick={() => {
                    // Reset all and start over if they really want to restart everything
                    setFiles(prev => prev.map(f => ({ ...f, status: 'pending', error: undefined })));
                  }}
                  className="px-6 py-4 rounded-2xl font-bold text-slate-400 hover:text-slate-600 transition-all"
                >
                  Restart All
                </button>
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleBulkSubmit(true)}
                  className="bg-rose-600 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-xl shadow-rose-100 hover:bg-rose-700 transition-all flex items-center gap-3"
                >
                  <Send className="w-6 h-6" />
                  Retry Failed ({errorCount})
                </motion.button>
              </>
            ) : (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleBulkSubmit(false)}
                disabled={isSubmitting || files.length === 0 || (pendingCount === 0 && errorCount === 0)}
                className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-xl shadow-slate-200 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-3"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Send className="w-6 h-6" />
                    {pendingCount > 0 ? 'Start Bulk Review' : 'Restart All'}
                  </>
                )}
              </motion.button>
            )}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
