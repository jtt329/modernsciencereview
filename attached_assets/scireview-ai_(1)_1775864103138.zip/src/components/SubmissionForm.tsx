import React, { useState, useCallback } from 'react';
import { motion } from 'motion/react';
import { Send, X, BookOpen, Sparkles, Loader2, FileText, Link as LinkIcon, Upload, CheckCircle2, AlertCircle } from 'lucide-react';
import { useDropzone } from 'react-dropzone';
import { ReviewSource } from '../services/geminiService';

interface SubmissionFormProps {
  onSubmit: (source: ReviewSource) => Promise<void>;
  onClose: () => void;
}

export default function SubmissionForm({ onSubmit, onClose }: SubmissionFormProps) {
  const [submissionType, setSubmissionType] = useState<'pdf' | 'text'>('pdf');
  const [text, setText] = useState('');
  const [pdfFile, setPdfFile] = useState<File | null>(null);
  const [pdfBase64, setPdfBase64] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError(null);
    const file = acceptedFiles[0];
    if (file && file.type === 'application/pdf') {
      setPdfFile(file);
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(',')[1];
        setPdfBase64(base64);
      };
      reader.readAsDataURL(file);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    multiple: false,
    disabled: isSubmitting
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    let source: ReviewSource | null = null;
    if (submissionType === 'pdf' && pdfBase64) {
      source = { type: 'pdf', data: pdfBase64 };
    } else if (submissionType === 'text' && text.trim()) {
      source = { type: 'text', data: text.trim() };
    }

    if (source) {
      setIsSubmitting(true);
      try {
        await onSubmit(source);
        onClose();
      } catch (err: any) {
        console.error('Submission failed:', err);
        setError(err.message || 'Submission failed. Please check your API key and try again.');
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const isFormValid = (
    (submissionType === 'pdf' && pdfBase64) ||
    (submissionType === 'text' && text.trim())
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-indigo-600 text-white">
          <div className="flex items-center gap-3">
            <div className="bg-white/20 p-2 rounded-xl">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-black tracking-tight">Submit Scientific Paper</h2>
              <p className="text-xs font-bold text-indigo-200 uppercase tracking-widest">Minimal Friction Journal</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          <div className="space-y-4">
            <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Submission Method</label>
            <div className="flex gap-2">
              {[
                { id: 'pdf', label: 'PDF File', icon: FileText },
                { id: 'text', label: 'Raw Text', icon: Upload }
              ].map((type) => (
                <button
                  key={type.id}
                  onClick={() => setSubmissionType(type.id as any)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-sm transition-all ${
                    submissionType === type.id 
                      ? 'bg-indigo-600 text-white shadow-md' 
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <type.icon className="w-4 h-4" />
                  {type.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex-1">
            {error && (
              <div className="mb-6 p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center gap-3 text-rose-600 text-sm font-bold">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p>{error}</p>
              </div>
            )}
            {submissionType === 'pdf' && (
              <div 
                {...getRootProps()} 
                className={`border-2 border-dashed rounded-3xl p-12 text-center transition-all cursor-pointer ${
                  isDragActive ? 'border-indigo-500 bg-indigo-50' : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
                }`}
              >
                <input {...getInputProps()} />
                {pdfFile ? (
                  <div className="flex flex-col items-center gap-3">
                    <div className="bg-green-100 p-4 rounded-full">
                      <CheckCircle2 className="w-12 h-12 text-green-600" />
                    </div>
                    <div>
                      <p className="text-lg font-bold text-slate-900">{pdfFile.name}</p>
                      <p className="text-sm text-slate-500">{(pdfFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setPdfFile(null);
                        setPdfBase64(null);
                      }}
                      className="text-sm font-bold text-rose-500 hover:text-rose-600 underline"
                    >
                      Remove File
                    </button>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-4">
                    <div className="bg-indigo-50 p-4 rounded-full">
                      <Upload className="w-12 h-12 text-indigo-600" />
                    </div>
                    <div>
                      <p className="text-lg font-bold text-slate-900">Drop your PDF here</p>
                      <p className="text-sm text-slate-500">or click to browse from your computer</p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {submissionType === 'text' && (
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Paste your paper content here..."
                className="w-full min-h-[300px] text-lg text-slate-700 placeholder:text-slate-200 border-none focus:ring-0 p-0 resize-none leading-relaxed"
                disabled={isSubmitting}
              />
            )}
          </div>
        </div>

        <div className="p-6 border-t border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-500">
            <Sparkles className="w-5 h-5 text-indigo-600" />
            <span className="text-sm font-bold uppercase tracking-wider">AI Review will be generated instantly</span>
          </div>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleSubmit}
            disabled={isSubmitting || !isFormValid}
            className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-lg shadow-xl shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center gap-3"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-6 h-6 animate-spin" />
                Reviewing...
              </>
            ) : (
              <>
                <Send className="w-6 h-6" />
                Submit & Review
              </>
            )}
          </motion.button>
        </div>
      </motion.div>
    </motion.div>
  );
}
