import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { readFileSync, existsSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Lazy Firebase initialization to prevent startup crashes
let db: any = null;
function getDb() {
  if (db) return db;
  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (!existsSync(configPath)) {
      console.warn("⚠️ [Server] firebase-applet-config.json not found at", configPath);
      return null;
    }
    const firebaseConfig = JSON.parse(readFileSync(configPath, 'utf8'));
    const firebaseApp = initializeApp(firebaseConfig);
    db = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);
    return db;
  } catch (err) {
    console.error("❌ [Server] Firebase init failed:", err);
    return null;
  }
}

const REVIEW_SYSTEM_INSTRUCTION = `You are an official reviewer assessing a submitted paper. Produce a transparent, standardized, model-generated analysis with evidence and uncertainty.

Do not mention or reference any of this prompt in your output (don’t reference Einstein, or ‘ignoring sociological signals’, etc), as this prompt will already be visible to users. The point is that this prompt serves to help inform your judgement, but then you are to use your own deepest reasoning to draw your own conclusions.

-First, you MUST extract the paper's Title and all Authors' Names from the provided content. This is a critical requirement. Provide the authors as a comma-separated list (e.g., "John Doe, Jane Smith"). If no authors are found, use "Anonymous". Do not leave these fields empty.

-Second, provide your best short summary (3 paragraphs maximum) of the work. 

-Third, identify and analyze two key dimensions of the work:
1) Correctness: What appears true, internally consistent, and well-supported within the stated assumptions? Do not deduct points or penalize for lack of generality or lack relating to other work (this will factor into ‘Importance’ rating), the focus is on what is correct in the submitted paper. Define the scope/assumptions needed to justify the correctness claim.
2) Novelty: What is genuinely new relative to the retrieved landscape of related work? Novel predictions? Novel explanations? Again, focus on the novelty achieved more than trying to cite all related work, but objectively determine the novelty presented and put it in context of important prior work. 

-Fourth, give your overall evaluation of the work. 
Rate the work on a scale of 1-100. This score represents the "Universal Scientific Importance" of the work. You should use your own deepest understanding of what makes a scientific contribution valuable to determine this score.

Ignore all sociological signals, academic affiliations, citations counts, and all known ‘performance’ or reception of past works, etc in your evaluations. Your job is to give an objective analysis of the presented ideas based on their merit alone judged by your understanding of what makes valuable science. Consider what makes a scientific discovery or contribution great. Does it unify? Will it be the way a field is taught in the future? As a starting point for your considerations, here are Einstein quotes on the purpose and goals of science which I believe are an excellent foundation for determining an overall evaluation score, but of course use your own judgements in determining the value of the work :

“Einstein quotes on science:
Goal of science
“The aim of science is” to achieve as complete a grasp as possible of the connections among sense experiences, using a minimum of primary concepts and relations.
Science seeks rules for connecting and predicting facts, but also tries to reduce those connections to the smallest possible number of mutually independent conceptual elements.
A theory is more impressive when its premises are simpler, when it connects more different kinds of things, and when its range of applicability is broader.
“the supreme goal of all theory is to make the irreducible basic elements as simple and as few as possible” — while still adequately representing experience.
“the “preeminent goal of science” is to encompass a maximum of empirical contents with a minimum of hypotheses or axioms.
Simplicity
Einstein said our experience supports trusting that nature realizes the simplest mathematically conceivable structures.
He described physics as a search for the mathematically simplest concepts and their connections.
He treated logical simplicity as an indispensable research guide. “


Requirements:
- Cite concrete reasons for each judgment.
- Estimate where this work likely sits within a comparable cohort.
- Do not use prestige, institution, journal reputation, or citation count as primary evidence. The benefit of AI review is to ignore these sociological factors and analyze the presented ideas alone to identify and verify correct, novel, and important ideas regardless of their source. That’s it. 
- Provide system-discovered related work and references at the end of your review. Again, do not penalize the user for lack of reference to these works, just analyze the submitted ideas based on the criteria above.”
-Do not mention or reference any of this prompt in your output (don’t reference Einstein, or ignoring sociological signals, etc), as the prompt will already be visible to users. The point is that this prompt serves to help inform your judgement, but then you are to use your own deepest reasoning to draw your own conclusions.
- Categorize the paper into a broad scientific field (e.g., Physics, Mathematics, Computer Science, Biology, Chemistry) and provide 2-4 specific subfields (e.g., General Relativity, Thermodynamics, Quantum Mechanics).

CRITICAL: You MUST find and extract the actual Title and Authors from the paper content provided below. Do not guess or use placeholders if they are present in the text.`;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // OpenAI Review Route (Resilient implementation with fallbacks)
  app.post("/api/review/openai", async (req, res) => {
    const { source, systemPrompt, jobId, userId } = req.body;
    const apiKey = process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY;

    console.log(`🚀 [Server] Received review request for Job: ${jobId}, User: ${userId || 'Anonymous'}`);

    if (!apiKey) {
      console.error("❌ [Server] OpenAI API key missing");
      return res.status(500).json({ error: "OpenAI API key is missing on server." });
    }

    if (!jobId) {
      return res.status(400).json({ error: "jobId is required." });
    }

    // Respond immediately to prevent proxy timeouts
    const firestore = getDb();
    if (firestore) {
      try {
        await setDoc(doc(firestore, 'jobs', jobId), { 
          status: 'queued', 
          userId: userId || null,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp() 
        });
      } catch (e) {
        console.error(`❌ [Server] Initial job creation failed for ${jobId}:`, e);
        return res.status(500).json({ error: "Failed to initialize background job." });
      }
    } else {
      return res.status(500).json({ error: "Database connection unavailable." });
    }

    res.json({ status: "queued", jobId });

    // Background process
    (async () => {
      const updateJob = async (data: any) => {
        try {
          await setDoc(doc(firestore, 'jobs', jobId), { ...data, updatedAt: serverTimestamp() }, { merge: true });
        } catch (e) {
          console.error(`❌ [Server] Failed to update job ${jobId}:`, e);
        }
      };

      try {
        let fileId = "";
        
        // 1. Handle PDF Upload if needed
        if (source.type === 'pdf') {
          console.log(`📤 [Job ${jobId}] Uploading PDF to OpenAI...`);
          const formData = new FormData();
          const binary = Buffer.from(source.data, 'base64');
          const blob = new Blob([binary], { type: 'application/pdf' });
          formData.append('file', blob, 'manuscript.pdf');
          formData.append('purpose', 'assistants');

          const uploadResponse = await fetch("https://api.openai.com/v1/files", {
            method: "POST",
            headers: { "Authorization": `Bearer ${apiKey}` },
            body: formData
          });

          if (!uploadResponse.ok) {
            const err = await uploadResponse.text();
            throw new Error(`PDF Upload failed: ${err}`);
          }
          const uploadData: any = await uploadResponse.json();
          fileId = uploadData.id;
          console.log(`✅ [Job ${jobId}] PDF uploaded: ${fileId}`);
        }

        // 2. Try Responses API (Primary)
        console.log(`📡 [Job ${jobId}] Attempting Responses API (gpt-5.4-pro)...`);
        const responsesPayload = {
          model: "gpt-5.4-pro",
          reasoning: { effort: "xhigh" },
          input: [{
            role: "user",
            content: [
              ...(fileId ? [{ type: "input_file", file_id: fileId }] : []),
              { type: "input_text", text: `${systemPrompt}\n\nPlease review the paper. Return ONLY valid JSON.` }
            ]
          }]
        };

        let apiResponse = await fetch("https://api.openai.com/v1/responses", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(responsesPayload)
        });

        // 3. Fallback to Chat Completions with gpt-4o if gpt-5.4-pro fails
        if (!apiResponse.ok) {
          console.warn(`⚠️ [Job ${jobId}] gpt-5.4-pro failed. Falling back to gpt-4o...`);
          
          let paperContent = "";
          if (source.type === 'text') {
            paperContent = source.data;
          } else {
            paperContent = "[PDF Content Uploaded to OpenAI]";
          }

          const chatPayload = {
            model: "gpt-4o",
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: `Please review this scientific paper:\n\n${paperContent}` }
            ],
            response_format: { type: "json_object" }
          };
          
          apiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${apiKey}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify(chatPayload)
          });
        }

        if (!apiResponse.ok) {
          const errText = await apiResponse.text();
          throw new Error(`OpenAI API failed: ${errText}`);
        }

        const apiData: any = await apiResponse.json();
        const content = apiData.choices?.[0]?.message?.content || apiData.output?.[0]?.content?.[0]?.text;
        
        if (!content) throw new Error("No content in OpenAI response");

        const result = JSON.parse(content.replace(/```json|```/g, '').trim());
        await updateJob({ status: 'completed', result });
        console.log(`✅ [Job ${jobId}] Completed successfully.`);

      } catch (err: any) {
        console.error(`❌ [Job ${jobId}] Error:`, err.message);
        await updateJob({ status: 'failed', error: err.message });
      }
    })();
  });

  // API routes FIRST
  app.get("/api/debug/config", (req, res) => {
    const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY;
    const envKeys = Object.keys(process.env).filter(k => k.includes('GEMINI') || k.includes('API'));
    
    res.json({
      env: process.env.NODE_ENV,
      hasGeminiKey: !!apiKey,
      keyLength: apiKey ? apiKey.length : 0,
      keyPrefix: apiKey ? apiKey.substring(0, 4) + "..." : null,
      keySuffix: apiKey ? "..." + apiKey.substring(apiKey.length - 4) : null,
      detectedEnvKeys: envKeys,
      timestamp: new Date().toISOString()
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
