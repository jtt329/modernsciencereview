import { GoogleGenAI, Type } from "@google/genai";
import OpenAI from "openai";
import * as pdfjs from "pdfjs-dist";
import { db } from "../firebase";
import { doc, onSnapshot } from "firebase/firestore";

// Initialize PDF.js worker using a more reliable CDN (unpkg)
// For version 5.x, the worker is a module (.mjs)
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

export interface ReviewResult {
  title: string;
  authorName: string;
  summary: string;
  correctness: string;
  novelty: string;
  overallEvaluation: string;
  score: number;
  field: string;
  subfields: string[];
  relatedWork: string;
  modelName: string;
  systemPrompt: string;
}

export interface ReviewSource {
  type: 'text' | 'pdf';
  data: string; // base64 for pdf, raw text for text
}

const REVIEW_SYSTEM_INSTRUCTION = `You are an elite scientific researcher. Your sole objective is to evaluate the merit of the IDEAS presented, completely decoupled from any sociological signals.

### BLIND REVIEW PROTOCOL:
1. IGNORE ALL SOCIOLOGICAL SIGNALS: You must treat this paper as if it were written by an unknown researcher. Famous names, academic affiliations, previous citation counts, or known journal acceptance MUST play ABSOLUTELY ZERO ROLE in your judgment. 
2. PRESTIGE NEUTRALITY: Do not let the "academic polish" or sophisticated prose of established authors influence your perception of the underlying scientific value.

### EVALUATION CRITERIA:
Your primary task is to judge the ideas on their merit alone and determine their potential for a lasting contribution to science.

1. NOVELTY & CORRECTNESS:
   - Identify what is NEW and INTRODUCED FOR THE FIRST TIME in this specific paper.
   - Verify if the work is internally consistent and well-supported within its stated assumptions.
   - The goal is to identify new (novel) knowledge (correct).

2. UNIVERSAL SCIENTIFIC IMPORTANCE (Score 1-100):
   - Rate the work based on the lasting contribution of the novel ideas presented.
   - Does it provide a more fundamental explanation, unify disparate fields, simplify complex phenomena, or result in new experimental predictions?
   - Focus on the "Delta" of new knowledge provided by this specific submission.

### CORE PHILOSOPHY:
Your judgment must be 100% focused on the ideas alone. The main purpose here is not to replicate or reproduce a traditional journal, but to identify new scientific knowledge. 

Do not penalize for limitations in presentation or lack of comprehensiveness in the evidence, provided the core result is sound. It is your job as the researcher to understand the paper within the context of science as a whole. Judge the work based on the value of the ideas themselves.

### OUTPUT REQUIREMENTS:
- First, extract the Title and Authors.
- Second, provide a 3-paragraph summary.
- Third, analyze Correctness and Novelty.
- Fourth, provide the Overall Evaluation and Score (1-100).
- Fifth, categorize the field and subfields.
- Sixth, provide system-discovered related work.`;

const getEnv = (key: string): string | undefined => {
  return (import.meta as any).env[key] || (globalThis as any).process?.env?.[key];
};

async function extractTextFromPdf(base64: string): Promise<string> {
  try {
    const binary = atob(base64);
    const uint8Array = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      uint8Array[i] = binary.charCodeAt(i);
    }
    
    const loadingTask = pdfjs.getDocument({ data: uint8Array });
    const pdf = await loadingTask.promise;
    let fullText = "";
    
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(" ");
      fullText += pageText + "\n\n";
    }
    
    return fullText;
  } catch (err) {
    console.error("PDF text extraction failed:", err);
    throw new Error("Failed to extract text from PDF. Please ensure it's a valid PDF file.");
  }
}

async function reviewWithOpenAI(source: ReviewSource, userId?: string): Promise<ReviewResult> {
  const jobId = `job_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  console.log(`🚀 Starting async OpenAI review (Job ID: ${jobId}, User: ${userId || 'Anonymous'})...`);
  
  try {
    // Start the job on the server
    const startResponse = await fetch("/api/review/openai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        source,
        systemPrompt: REVIEW_SYSTEM_INSTRUCTION,
        jobId,
        userId
      })
    });

    if (!startResponse.ok) {
      const errData = await startResponse.json();
      throw new Error(errData.error || "Failed to start OpenAI review");
    }

    console.log("⏳ Job queued. Waiting for deep reasoning to complete (this may take several minutes)...");

    // Poll Firestore for the result using onSnapshot (real-time)
    return new Promise((resolve, reject) => {
      const unsubscribe = onSnapshot(doc(db, 'jobs', jobId), (snapshot) => {
        if (!snapshot.exists()) return;

        const data = snapshot.data();
        if (data.status === 'completed') {
          console.log("✅ Deep reasoning complete!");
          unsubscribe();
          
          const result = data.result;
          // Validation to prevent undefined values in Firestore
          const requiredFields = ["title", "authorName", "summary", "correctness", "novelty", "overallEvaluation", "score", "field", "subfields", "relatedWork"];
          for (const field of requiredFields) {
            if (result[field] === undefined || result[field] === null) {
              result[field] = field === "score" ? 0 : field === "subfields" ? [] : "Not extracted";
            }
          }

          resolve({
            ...result,
            modelName: "gpt-5.4-pro", 
            systemPrompt: REVIEW_SYSTEM_INSTRUCTION
          });
        } else if (data.status === 'failed') {
          console.error("❌ Deep reasoning failed:", data.error);
          unsubscribe();
          reject(new Error(data.error || "OpenAI reasoning process failed."));
        }
      }, (err) => {
        console.error("❌ Firestore polling error:", err);
        unsubscribe();
        reject(new Error("Lost connection to reasoning engine. Please try again."));
      });

      // Optional: Set a client-side timeout (e.g., 30 minutes)
      setTimeout(() => {
        unsubscribe();
        reject(new Error("Reasoning process timed out. The paper might be too complex or the service is busy. Deep reasoning with gpt-5.4-pro can take up to 20-30 minutes for complex manuscripts."));
      }, 1800000);
    });
  } catch (err: any) {
    console.error("❌ OpenAI Review initiation failed:", err);
    throw err;
  }
}

export function getActiveModelName(): string {
  const openAIKey = getEnv("VITE_OPENAI_API_KEY");
  if (openAIKey) return "gpt-5.4-pro";
  return "gemini-3.1-pro-preview";
}

export async function reviewPaper(source: ReviewSource, userId?: string): Promise<ReviewResult> {
  // Check if OpenAI key is available, if so, use it as the primary high-tier reviewer
  const openAIKey = getEnv("VITE_OPENAI_API_KEY");
  if (openAIKey) {
    console.log("🚀 OpenAI API Key detected. Triggering review with gpt-5.4-pro (Responses API)...");
    try {
      const result = await reviewWithOpenAI(source, userId);
      console.log("✅ OpenAI Review successful:", result.title);
      return result;
    } catch (err) {
      console.error("❌ OpenAI review failed, falling back to Gemini:", err);
      // If it's a 502 or other network error, we definitely want to fall back
    }
  } else {
    console.log("ℹ️ No OpenAI API Key found. Using Gemini as default reviewer.");
  }

  const apiKey = getEnv("VITE_GEMINI_API_KEY") || getEnv("GEMINI_API_KEY");
  
  if (!apiKey) {
    throw new Error("Gemini API key is missing. Please set VITE_GEMINI_API_KEY in the environment.");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const parts: any[] = [
    { text: REVIEW_SYSTEM_INSTRUCTION }
  ];

  if (source.type === 'pdf') {
    parts.push({ text: "--- BEGIN PAPER CONTENT (PDF) ---" });
    parts.push({
      inlineData: {
        data: source.data,
        mimeType: 'application/pdf'
      }
    });
    parts.push({ text: "--- END PAPER CONTENT (PDF) ---" });
  } else {
    parts.push({ text: `--- BEGIN PAPER CONTENT (TEXT) ---\n${source.data}\n--- END PAPER CONTENT (TEXT) ---` });
  }

  const config: any = {
    systemInstruction: REVIEW_SYSTEM_INSTRUCTION,
    responseMimeType: "application/json",
    responseSchema: {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING, description: "The extracted title of the paper." },
        authorName: { type: Type.STRING, description: "A comma-separated list of all extracted authors." },
        summary: { type: Type.STRING, description: "3 paragraph summary of the work." },
        correctness: { type: Type.STRING, description: "Detailed analysis of correctness." },
        novelty: { type: Type.STRING, description: "Detailed analysis of novelty." },
        overallEvaluation: { type: Type.STRING, description: "Detailed analysis of importance/value." },
        score: { type: Type.NUMBER, description: "Overall evaluation score on a scale of 1-100." },
        field: { type: Type.STRING, description: "Broad scientific field (e.g., Physics)." },
        subfields: { 
          type: Type.ARRAY, 
          items: { type: Type.STRING },
          description: "2-4 specific subfields (e.g., General Relativity)." 
        },
        relatedWork: { type: Type.STRING, description: "System-discovered related work and references." },
      },
      required: ["title", "authorName", "summary", "correctness", "novelty", "overallEvaluation", "score", "field", "subfields", "relatedWork"],
    },
    tools: [{ googleSearch: {} }]
  };

  // Retry logic for 503 errors and fallback
  let response;
  let retries = 5;
  let currentModel = "gemini-3.1-pro-preview";
  
  while (retries > 0) {
    try {
      response = await ai.models.generateContent({
        model: currentModel,
        contents: { parts },
        config,
      });
      break; // Success!
    } catch (error: any) {
      const isBusy = error.message?.includes('503') || error.message?.includes('UNAVAILABLE') || error.message?.includes('high demand');
      
      if (isBusy) {
        console.log(`Gemini busy (${currentModel}), retrying... (${retries} left)`);
        retries--;
        
        // On second to last retry, try switching to Flash model which is more available
        if (retries === 1 && currentModel !== "gemini-3-flash-preview") {
          console.log("Switching to Flash model due to high demand on Pro...");
          currentModel = "gemini-3-flash-preview";
        }
        
        await new Promise(resolve => setTimeout(resolve, 3000)); // Wait 3 seconds
        if (retries === 0) throw error;
      } else {
        throw error; // Not a busy error, throw immediately
      }
    }
  }

  const responseText = response?.text;
  if (!responseText) throw new Error("No response from Gemini");
  
  let result;
  try {
    // Clean the response text in case it's wrapped in markdown code blocks
    const cleanedText = responseText.replace(/```json\n?|```/g, '').trim();
    result = JSON.parse(cleanedText);
  } catch (parseError) {
    console.error("Failed to parse Gemini response as JSON:", responseText);
    throw new Error("The AI returned an invalid data format. Please try again.");
  }

  return {
    ...result,
    modelName: currentModel,
    systemPrompt: REVIEW_SYSTEM_INSTRUCTION
  };
}
