import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, CheckCircle2, Zap, Award, Heart, MessageSquare, Info, X } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import { AIReview } from '../types';

interface ReviewCardProps {
  review: AIReview;
  onLike: (id: string, e: React.MouseEvent) => void;
  isLiked: boolean;
}

const SYSTEM_PROMPT_TEXT = `You are an elite scientific researcher. Your sole objective is to evaluate the merit of the IDEAS presented, completely decoupled from any sociological signals.

### BLIND REVIEW PROTOCOL:
1. IGNORE ALL SOCIOLOGICAL SIGNALS: You must treat this paper as if it were written by an unknown researcher. Famous names, academic affiliations, previous citation counts, or known journal acceptance MUST play ABSOLUTELY ZERO ROLE in your judgment. 
2. PRESTIGE NEUTRALITY: Do not let the "academic polish" or sophisticated prose of established authors influence your perception of the underlying scientific value.

### EVALUATION CRITERIA:
Your primary task is to judge the ideas on their merit alone and determine their potential for a lasting contribution to science.

1. NOVELTY & CORRECTNESS:
   - Identify what is NEW and INTRODUCED FOR THE FIRST TIME in this specific paper.
   - Verify if the work is internally consistent and well-supported within its stated assumptions.
   - The goal is to identify new (novel) knowledge (correct).

2. UNIVERSAL SCIENTIFIC IMPORTANCE (Score 1-100):
   - Rate the work based on the lasting contribution of the novel ideas presented.
   - Does it provide a more fundamental explanation, unify disparate fields, simplify complex phenomena, or result in new experimental predictions?
   - Focus on the "Delta" of new knowledge provided by this specific submission.

### CORE PHILOSOPHY:
Your judgment must be 100% focused on the ideas alone. The main purpose here is not to replicate or reproduce a traditional journal, but to identify new scientific knowledge. 

Do not penalize for limitations in presentation or lack of comprehensiveness in the evidence, provided the core result is sound. It is your job as the researcher to understand the paper within the context of science as a whole. Judge the work based on the value of the ideas themselves.

### OUTPUT REQUIREMENTS:
- First, extract the Title and Authors.
- Second, provide a 3-paragraph summary.
- Third, analyze Correctness and Novelty.
- Fourth, provide the Overall Evaluation and Score (1-100).
- Fifth, categorize the field and subfields.
- Sixth, provide system-discovered related work.`;

export default function ReviewCard({ review, onLike, isLiked }: ReviewCardProps) {
  const [showPrompt, setShowPrompt] = useState(false);

  const MarkdownRenderer = ({ content }: { content: string }) => (
    <div className="markdown-body prose prose-slate max-w-none prose-sm md:prose-base">
      <ReactMarkdown 
        remarkPlugins={[remarkMath]} 
        rehypePlugins={[rehypeKatex]}
      >
        {content}
      </ReactMarkdown>
    </div>
  );

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-indigo-50 to-white rounded-3xl border border-indigo-100 shadow-lg p-8 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <Sparkles className="w-24 h-24 text-indigo-600" />
        </div>

        <div className="flex items-center justify-between mb-8 relative z-10">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2.5 rounded-xl shadow-md">
              <Award className="w-6 h-6 text-white" />
            </div>
            <div className="flex flex-col">
              <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                {review.modelName?.includes('gpt') ? 'OpenAI AI Review' : 'Gemini AI Review'}
              </h2>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest">Verified Scientific Assessment</span>
                {review.modelName && (
                  <div className="flex items-center gap-1.5 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">
                      API Verified: {review.modelName}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
          <button 
            onClick={() => setShowPrompt(true)}
            className="flex items-center gap-1.5 text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-full transition-colors"
          >
            <Info className="w-3.5 h-3.5" />
            View System Prompt
          </button>
        </div>

        <div className="flex flex-col items-center justify-center mb-8 p-6 bg-white rounded-3xl border-2 border-indigo-500 shadow-xl shadow-indigo-100 relative overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
          <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-2 relative z-10">Overall Scientific Merit Score</span>
          <div className="flex items-baseline gap-1 relative z-10">
            <span className="text-7xl font-black text-slate-900 tracking-tighter leading-none">{review.score}</span>
            <span className="text-2xl font-bold text-slate-400">/100</span>
          </div>
          <div className="mt-4 w-full h-2 bg-slate-100 rounded-full overflow-hidden relative z-10">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${review.score}%` }}
              transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
              className="h-full bg-indigo-600"
            />
          </div>
        </div>

        <div className="bg-indigo-900 text-white p-6 rounded-2xl shadow-inner mb-8">
          <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-300 mb-2">Executive Summary</h4>
          <MarkdownRenderer content={review.summary} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white/60 backdrop-blur-sm p-5 rounded-2xl border border-indigo-50 hover:border-indigo-200 transition-colors">
            <div className="flex items-center gap-2 mb-3 text-indigo-600">
              <CheckCircle2 className="w-5 h-5" />
              <h4 className="font-bold text-sm uppercase tracking-wider">Correctness</h4>
            </div>
            <MarkdownRenderer content={review.correctness} />
          </div>

          <div className="bg-white/60 backdrop-blur-sm p-5 rounded-2xl border border-indigo-50 hover:border-indigo-200 transition-colors">
            <div className="flex items-center gap-2 mb-3 text-indigo-600">
              <Zap className="w-5 h-5" />
              <h4 className="font-bold text-sm uppercase tracking-wider">Novelty</h4>
            </div>
            <MarkdownRenderer content={review.novelty} />
          </div>

          <div className="bg-white/60 backdrop-blur-sm p-5 rounded-2xl border border-indigo-50 hover:border-indigo-200 transition-colors">
            <div className="flex items-center gap-2 mb-3 text-indigo-600">
              <Award className="w-5 h-5" />
              <h4 className="font-bold text-sm uppercase tracking-wider">Overall Evaluation</h4>
            </div>
            <MarkdownRenderer content={review.overallEvaluation} />
          </div>
        </div>

        <div className="bg-white/40 backdrop-blur-sm p-6 rounded-2xl border border-indigo-50 mb-6">
          <h4 className="text-xs font-bold uppercase tracking-widest text-indigo-600 mb-2">Related Work & References</h4>
          <MarkdownRenderer content={review.relatedWork} />
        </div>

        <div className="flex items-center gap-6 pt-4 border-t border-indigo-100">
          <button 
            onClick={(e) => onLike(review.id, e)}
            className={`flex items-center gap-2 text-sm font-bold transition-colors ${isLiked ? 'text-rose-500' : 'text-slate-500 hover:text-rose-500'}`}
          >
            <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
            {review.likesCount} Likes
          </button>
          <div className="flex items-center gap-2 text-sm font-bold text-slate-500">
            <MessageSquare className="w-5 h-5" />
            Comments
          </div>
          <div className="ml-auto flex flex-col items-end gap-1">
            <div className="flex items-center gap-2 px-3 py-1 bg-indigo-50 rounded-lg border border-indigo-100">
              <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
              <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">
                {review.modelName}
              </span>
            </div>
            <span className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">
              Verified Reasoning Process Active
            </span>
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {showPrompt && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md"
            onClick={() => setShowPrompt(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-indigo-600 text-white">
                <div className="flex items-center gap-3">
                  <Info className="w-6 h-6" />
                  <div>
                    <h3 className="text-xl font-black tracking-tight">System Prompt</h3>
                    {review.modelName && <p className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest">Used with {review.modelName}</p>}
                  </div>
                </div>
                <button onClick={() => setShowPrompt(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="p-8 overflow-y-auto bg-slate-50">
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <pre className="text-sm text-slate-700 whitespace-pre-wrap font-sans leading-relaxed">
                    {review.systemPrompt || SYSTEM_PROMPT_TEXT}
                  </pre>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
